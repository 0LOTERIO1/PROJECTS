package br.com.fiap.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.fiap.jdbc.factory.ConnectionFactory;
import br.com.fiap.jdbc.model.Consultoras;

public class ConsultorasDAO {
	private Connection connection;

	public ConsultorasDAO() {
		this.connection = new ConnectionFactory().getConnection(); 
	}

	// inserir
	public void insert(Consultoras consultoras) {
		String sql = "insert into consultoras(id_consultora,nome,telefone,endereco,cpf) values (seq_consultoras.nextval,?,?,?,?)";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, consultoras.getNome());
			stmt.setString(2, consultoras.getTelefone());
			stmt.setString(3, consultoras.getEndereco());
			stmt.setString(4, consultoras.getCpf());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// selecionar
	public Consultoras selectById(int idConsultoras) throws SQLException {
		Consultoras consultoras = null;
		String sql = "select * from consultoras where id_consultora=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, idConsultoras);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				consultoras = new Consultoras();
				consultoras.setIdConsultora(rs.getInt("id_Consultora"));
				consultoras.setNome(rs.getString("nome"));
				consultoras.setTelefone(rs.getString("telefone"));
				consultoras.setEndereco(rs.getString("endereco"));
				consultoras.setCpf(rs.getString("cpf"));

			}
			rs.close();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return consultoras;
	}

	// update
	public void update(Consultoras consultoras) {
		String sql = "update consultoras set nome=?, telefone=?,endereco=?,cpf=? where id_consultora=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, consultoras.getNome());
			stmt.setString(2, consultoras.getTelefone());
			stmt.setString(3, consultoras.getEndereco());
			stmt.setString(4, consultoras.getCpf());
			stmt.setInt(5, consultoras.getIdConsultora());
			
			stmt.execute();
	        stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	//delete
	public void delete(int idConsultoras) {
		String sql = "delete from consultoras where id_Consultora=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setLong(1, idConsultoras);
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
