package br.com.fiap.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.fiap.jdbc.factory.ConnectionFactory;
import br.com.fiap.jdbc.model.Clientes;
import br.com.fiap.jdbc.model.Produtos;

public class ProdutosDAO {
	private Connection connection;
	
	public ProdutosDAO() {
		this.connection = new ConnectionFactory().getConnection(); 
	}
	
	//inserir
	public void insert(Produtos produtos) {
		String sql = "insert into produto(id_produto, nome, preco) values (seq_produtos.nextval, ?,?)";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1,produtos.getNome() );
			stmt.setDouble(2, produtos.getPreco());
			
			stmt.execute();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	//selectbyid
	public Produtos selectById(int idProduto) throws SQLException{
		Produtos produtos = null;
		try {
			String sql = "select * from produto where Id_produto=?";
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, idProduto);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				produtos = new Produtos();
				produtos.setIdProduto(rs.getInt("Id_produto"));
				produtos.setNome(rs.getString("nome"));
				produtos.setPreco(rs.getDouble("preco"));
				
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return produtos;
		
	}
		//alterar
	public void update(Produtos produtos) {
	    String sql = "UPDATE produto SET nome=?, preco=? WHERE id_produto=?";
	    try {
	        PreparedStatement stmt = connection.prepareStatement(sql);
	        stmt.setString(1, produtos.getNome());
	        stmt.setDouble(2, produtos.getPreco());
	        stmt.setInt(3, produtos.getIdProduto());
	     
	        stmt.execute();
	        stmt.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	public void delete(int idProdutos) {
		String sql = "delete from produto where id_produto=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, idProdutos);
			stmt.execute();
			stmt.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
