package br.com.fiap.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.fiap.jdbc.factory.ConnectionFactory;
import br.com.fiap.jdbc.model.Clientes;

public class ClientesDAO {
	private Connection connection;

	public ClientesDAO() {
		this.connection = new ConnectionFactory().getConnection(); 
	}
	
	
	//inserir
public void insert(Clientes clientes) {
	String sql = "insert into clientes(id_cliente, nome, endereco, email, telefone) values(seq_clientes.nextval, ?, ?, ?, ?)";

	PreparedStatement stmt;
	try {
	    stmt = connection.prepareStatement(sql);
	    
	    stmt.setString(1, clientes.getNome());
	    stmt.setString(2, clientes.getEndereco());
	    stmt.setString(3, clientes.getEmail());
	    stmt.setString(4, clientes.getTelefone());
	    
	    stmt.execute();
	    stmt.close();
	
	} catch(SQLException e) {
		
		e.printStackTrace();
	}
}

     //selectbyid
public Clientes selectById(int idCliente ) throws SQLException{
	Clientes clientes = null;
	try {
		String sql = "select * from clientes where Id_cliente=?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setInt(1, idCliente);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			clientes = new Clientes();
			clientes.setIdCliente(rs.getInt("id_Cliente"));
			clientes.setNome(rs.getString("nome"));
			clientes.setEndereco(rs.getString("endereco"));
			clientes.setEmail(rs.getString("email"));
			clientes.setTelefone(rs.getString("telefone"));
			
			
		}
		rs.close();
		stmt.close();
	}catch (SQLException e) {
		e.printStackTrace();
	}
	return clientes;
}
public void update(Clientes clientes) {
    String sql = "UPDATE clientes SET nome=?, endereco=?, email=?, telefone=? WHERE id_cliente=?";
    try {
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, clientes.getNome());
        stmt.setString(2, clientes.getEndereco());
        stmt.setString(3, clientes.getEmail());
        stmt.setString(4, clientes.getTelefone());
        stmt.setInt(5, clientes.getIdCliente());  // Usando o ID do objeto `Clientes`
        stmt.execute();
        stmt.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}



	public void delete(int idCliente) {
		String sql = "delete from clientes where id_Cliente=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, idCliente);
			stmt.execute();
			stmt.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}

	
	

