package br.com.fiap.test;

import java.sql.SQLException;

import br.com.fiap.jdbc.dao.ClientesDAO;
import br.com.fiap.jdbc.dao.ConsultorasDAO;
import br.com.fiap.jdbc.dao.ProdutosDAO;
import br.com.fiap.jdbc.model.Clientes;
import br.com.fiap.jdbc.model.Consultoras;
import br.com.fiap.jdbc.model.Produtos;

public class Teste {

	public static void main(String[] args) throws SQLException {

		/*
				
				*/
		ProdutosDAO dao = new ProdutosDAO();
		ConsultorasDAO dao1 = new ConsultorasDAO();
		ClientesDAO dao2 = new ClientesDAO();

		Produtos perfumes = new Produtos("KAIAK NATURA", 140.00);
		Produtos perfumes1 = new Produtos("ARBO NATURA", 63.50);
		Produtos perfumes2 = new Produtos("COLONIA", 59.90);

		Consultoras consultoras1 = new Consultoras("Elisabete", "11995764525", "rua guarita 222", "373.548.938-97");
		Consultoras consultoras2 = new Consultoras("Karine", "11995878523", "rua jardim dos ipes 555", "17.181.140-70");
		Consultoras consultoras3 = new Consultoras("Rosangela", "1198741235", "rua donelio 111", "301.252.363-96");

		Clientes cliente1 = new Clientes("mario", "rua aparecida 33", "mario@gmail.com", "11858547855");
		Clientes cliente2 = new Clientes("marina", "rua aparecida 55", "marina@gmail.com", "1263547855");
		Clientes cliente3 = new Clientes("josé", "rua aparecida 33", "jose@gmail.com", "1285859785");
		// INSERIR DADOS DA TABELA
		// dao.insert(perfumes);
		// dao.insert(perfumes1);
		// dao.insert(perfumes2);
		// dao1.insert(consultoras1);
		// dao1.insert(consultoras2);
		// dao1.insert(consultoras3);
		// dao2.insert(cliente1);
		// dao2.insert(cliente2);
		// dao2.insert(cliente3);

		// ATUALIZAR DADOS NA TABELA
		// Produtos perfumes = new Produtos("OUTRO PERFUME NATURA", 140.00);
		// perfumes.setIdProduto(1);
		// dao.update(perfumes);
		// Produtos perfumesAlterados = dao.selectById(2);
		// System.out.println(perfumesAlterados);

		// Consultoras consultoras1 = new Consultoras("maria", "09999999999999", "rua
		// X", "969655858");
		// consultoras1.setIdConsultora(1);
		// dao1.update(consultoras1);
		// Consultoras consultorasAlteradas = dao1.selectById(1);
		// System.out.println(consultorasAlteradas);

		// Clientes cliente1 = new Clientes("pedro", "rua guaraira 152", "11969698585",
		// "6552525252");
		// cliente1.setIdCliente(1);
		// dao2.update(cliente1);
		// Clientes clientesAlterados = dao2.selectById(1);
		// System.out.println(clientesAlterados);

		// SELECIONAR PELO ID
		//System.out.println(dao.selectById(1));
		//System.out.println(dao.selectById(2));
		//System.out.println(dao.selectById(3));
		//System.out.println("//////////////////////////////////////////////////////////////////////////////////////");
		//System.out.println(dao1.selectById(1));
		//System.out.println(dao1.selectById(2));
		//System.out.println(dao1.selectById(3));
		//System.out.println("//////////////////////////////////////////////////////////////////////////////////////");
		//System.out.println(dao2.selectById(1));
		//System.out.println(dao2.selectById(2));
		//System.out.println(dao2.selectById(3));

		// Deletar produtos da tabela
		//dao.delete(1);
		//dao.delete(2);
		//dao.delete(3);
		//System.out.println("//////////////////////////////////////////////////////////////////////////////////////");
		//dao1.delete(1);
		//dao1.delete(2);
		//dao1.delete(3);
		//System.out.println("//////////////////////////////////////////////////////////////////////////////////////");
		//dao2.delete(1);
		//dao2.delete(2);
		//dao2.delete(3);

	}
}
